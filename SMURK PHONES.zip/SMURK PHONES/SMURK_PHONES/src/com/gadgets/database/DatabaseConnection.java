package com.gadgets.database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.swing.JOptionPane;


public class DatabaseConnection {
    private static Connection con = null;

    public static Connection getConnection() {
              if (con != null) {
            return con; 
        }
        
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            
            String url = "jdbc:mysql://localhost:3306/Gadgets?zeroDateTimeBehavior=CONVERT_TO_NULL";
            String username = "root";
            String password = "isbat";
            
            con = DriverManager.getConnection(url, username, password);
            JOptionPane.showMessageDialog(null, "Connection Successful");
            return con;
            
        } catch (ClassNotFoundException e) {
            JOptionPane.showMessageDialog(null, "MySQL JDBC Driver not found. Include the MySQL connector jar in the project.");
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Connection Failed! Check output console\n" + e.getMessage());
        }
        
        return null;
    }

    public static void main(String[] args) {
        Connection con = getConnection();
        if (con != null) {
            System.out.println("Database connected successfully!");
        } else {
            System.out.println("Failed to connect to the database.");
        }
    }
}
