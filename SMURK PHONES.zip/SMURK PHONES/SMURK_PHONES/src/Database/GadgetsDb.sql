-- Create the Gadgets database and use it
CREATE DATABASE IF NOT EXISTS Gadgets;
USE Gadgets;
-- Admin table
CREATE TABLE IF NOT EXISTS admin_T (
    user_id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(30) NOT NULL,
    password VARCHAR(30) NOT NULL,
    gender VARCHAR(10) NOT NULL,
    security_word VARCHAR(23) NOT NULL,
    address VARCHAR(50) NOT NULL,
    contact VARCHAR(15) NOT NULL,
    email VARCHAR(50) UNIQUE
);

-- Receptionist table
CREATE TABLE IF NOT EXISTS Receptionist_T (
    user_id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(30) NOT NULL,
    password VARCHAR(30) NOT NULL,
    gender VARCHAR(10) NOT NULL,
    security_word VARCHAR(23) NOT NULL,
    address VARCHAR(50) NOT NULL,
    contact VARCHAR(15) NOT NULL,
    email VARCHAR(50) UNIQUE
);

-- Customers table
CREATE TABLE IF NOT EXISTS customers (
    customer_id INT AUTO_INCREMENT PRIMARY KEY,
    customer_name VARCHAR(100) NOT NULL,
    contact VARCHAR(15) NOT NULL,
    email VARCHAR(100),
    gender ENUM('Male', 'Female', 'Other') NOT NULL
);

-- Agents table (required for appointments)
CREATE TABLE IF NOT EXISTS agents (
    agent_id INT AUTO_INCREMENT PRIMARY KEY,
    agent_name VARCHAR(100) NOT NULL,
    contact VARCHAR(15) NOT NULL,
    email VARCHAR(100),
    gender ENUM('Male', 'Female', 'Other')
);
 CREATE TABLE IF NOT EXISTS employees (
    employee_id INT AUTO_INCREMENT PRIMARY KEY,
    employee_name VARCHAR(100) NOT NULL,
    role VARCHAR(50),
    contact VARCHAR(15),
    email VARCHAR(100) UNIQUE,
    gender ENUM('Male', 'Female', 'Other')
);



-- Services table (required for appointments)
CREATE TABLE IF NOT EXISTS services (
    service_id INT AUTO_INCREMENT PRIMARY KEY,
    service_name VARCHAR(100) NOT NULL,
    description TEXT,
    price DECIMAL(10, 2)
);

-- Appointments table
CREATE TABLE IF NOT EXISTS appointments (
    appointment_id INT AUTO_INCREMENT PRIMARY KEY,
    customer_id INT,
    service_id INT,
    agent_id INT,
    appointment_date DATE NOT NULL,
    duration TIME,
    price DECIMAL(10, 2),
    status VARCHAR(20),
    payment_status VARCHAR(20),
    FOREIGN KEY (customer_id) REFERENCES customers(customer_id),
    FOREIGN KEY (service_id) REFERENCES services(service_id),
    FOREIGN KEY (agent_id) REFERENCES agents(agent_id)
);
